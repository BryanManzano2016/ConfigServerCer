### Relevant Articles:
- [Quick Intro to Spring Cloud Configuration](http://www.baeldung.com/spring-cloud-configuration)
